from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(DInfant)
admin.site.register(D1InfantGrowth)
admin.site.register(D2InfantFeeding)
admin.site.register(D3InfantCardiovascular)
admin.site.register(D4InfantLungFunction)
admin.site.register(D5InfantBiological)
admin.site.register(D6CurrentSmoking)
admin.site.register(D7Infection)
admin.site.register(D8PollutantExposure)
