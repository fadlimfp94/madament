from __future__ import unicode_literals

from django.apps import AppConfig


class FormsDConfig(AppConfig):
    name = 'forms_d'
